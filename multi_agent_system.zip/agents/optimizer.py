from utils.llm import call_llm

def optimizer(content, review):
    prompt = f"""
根据审核意见优化内容：

原内容：
{content}

审核意见：
{review}

输出优化后的完整文案：
"""
    return call_llm(prompt)
