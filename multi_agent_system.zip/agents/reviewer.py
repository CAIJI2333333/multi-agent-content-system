from utils.llm import call_llm

def reviewer(content):
    prompt = f"""
请对以下内容进行审核：

{content}

检查：
1. 是否有违规表达
2. 是否夸大效果
3. 是否适合中老年人

输出：
- 问题点
- 修改建议
- 综合评分（0-100）
"""
    return call_llm(prompt)
