from utils.llm import call_llm

def writer(plan):
    prompt = f"""
根据以下结构生成短视频带货文案（适合中老年人，合规，不夸大）：

{plan}

要求：
- 有温度
- 像老朋友聊天
- 避免绝对化表达
"""
    return call_llm(prompt)
