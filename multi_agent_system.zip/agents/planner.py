from utils.llm import call_llm

def planner(task):
    prompt = f"""
你是一个内容规划专家，请将任务拆解为结构化步骤：
任务：{task}

输出格式：
1. 情感引入
2. 内容主体
3. 产品介绍
4. 转化引导
"""
    return call_llm(prompt)
