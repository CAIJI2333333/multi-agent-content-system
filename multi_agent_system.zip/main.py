from agents.planner import planner
from agents.writer import writer
from agents.reviewer import reviewer
from agents.optimizer import optimizer

def run_pipeline(task):
    print("🧠 规划中...")
    plan = planner(task)

    print("✍️ 生成中...")
    content = writer(plan)

    print("🔍 审核中...")
    review = reviewer(content)

    print("♻️ 优化中...")
    final_content = optimizer(content, review)

    return {
        "plan": plan,
        "draft": content,
        "review": review,
        "final": final_content
    }

if __name__ == "__main__":
    task = "为中老年人生成一段养生类短视频带货文案（黄芪豆浆粉）"
    result = run_pipeline(task)

    print("\n===== 最终结果 =====\n")
    print(result["final"])
